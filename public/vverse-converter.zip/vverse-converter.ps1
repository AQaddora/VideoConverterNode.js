param (
    [Parameter(Mandatory=$true, ValueFromPipeline=$true)]
    [string]$Path
)

if ($Path.Trim().StartsWith('"') -and $Path.Trim().EndsWith('"')) {
    $Path = $Path.Trim().Substring(1, $Path.Trim().Length - 2)
}

$outputFolder = Join-Path -Path $HOME -ChildPath "Videos\VVerseConverter"
$logFile = "ffmpeg.log"

if (-not (Test-Path $outputFolder)) {
    New-Item -ItemType Directory -Path $outputFolder | Out-Null
}

function Run-FFmpeg {
    param (
        [string]$InputFile,
        [string]$OutputFile
    )
    &ffmpeg.exe -i `"$InputFile`" -acodec copy -vcodec copy -movflags faststart `"$outputFile`"
}

if (Test-Path -Path $Path -PathType 'Leaf') {
    # Single video file
    $inputFile = $Path
    $outputFile = Join-Path -Path $outputFolder -ChildPath "vverse-friendly-$((Get-Item -Path $inputFile).BaseName).mp4"

    Run-FFmpeg -InputFile $inputFile -OutputFile $outputFile
}
else {
    # Folder containing videos
    $videoFiles = Get-ChildItem -Path $Path -Filter *.mp4 -File

    foreach ($file in $videoFiles) {
        $inputFile = $file.FullName
        $outputFile = Join-Path -Path $outputFolder -ChildPath "vverse-friendly-$($file.BaseName).mp4"

        Run-FFmpeg -InputFile $inputFile -OutputFile $outputFile
    }
}

Write-Host "Conversion complete!"
Write-Host "FFmpeg logs saved to: $logFile"